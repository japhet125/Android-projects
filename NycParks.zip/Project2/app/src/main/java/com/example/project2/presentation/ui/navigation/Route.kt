package com.example.project2.presentation.ui.navigation

object Route {
    const val HOME_SCREEN = "HOME"
    const val PARK_SCREEN ="PARKS"
}