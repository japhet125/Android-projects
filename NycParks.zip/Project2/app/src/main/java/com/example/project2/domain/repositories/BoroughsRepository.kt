package com.example.project2.domain.repositories

import com.example.project2.commons.AppError
import com.example.project2.commons.Either
import com.example.project2.domain.model.Borough

interface BoroughsRepository {
    suspend fun getBoroughs(): Either<AppError, List<Borough>>

}