package com.example.project2.util

object AppConstants {
    const val BOROUGHS_JSON = "boroughs.json"
    const val NYC_OPEN_DATA_API_BASE_URL = "https://nycopendata.socrata.com/resource/"
}