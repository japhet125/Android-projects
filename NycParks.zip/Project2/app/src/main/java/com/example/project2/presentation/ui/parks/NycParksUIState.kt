package com.example.project2.presentation.ui.parks

import com.example.project2.commons.AppError
import com.example.project2.data.models.NycParkResponse

//TODO: Project 2

//data class NycParksUIState()
data class NycParksUIState @JvmOverloads constructor(
    val isLoading: Boolean = false,
    val NycParks: List<NycParkResponse> = emptyList(),
    val error: AppError? = null
)
