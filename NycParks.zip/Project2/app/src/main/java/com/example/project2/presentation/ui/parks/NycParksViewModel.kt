package com.example.project2.presentation.ui.parks

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.project2.commons.Either
import com.example.project2.commons.Event
import com.example.project2.commons.TAG
import com.example.project2.commons.sendEvent
import com.example.project2.domain.repositories.NycParksRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

//https://youtu.be/BtHHNj3aiTQ?si=e93Jvg4X7k5nlxv-
@HiltViewModel
class NycParksViewModel @Inject constructor(
    private val repository: NycParksRepository
) : ViewModel() {

 // TODO: Project 2


    private  val _state  = MutableStateFlow(NycParksUIState())
    val state = _state.asStateFlow()

    fun getNycParks(borough: String) {
            viewModelScope.launch {
                _state.update {
                    it.copy(isLoading = true)
                }
                when (val result = repository.getParksByBorough(borough)){
                    is Either.Data -> {
                        Log.d(TAG, "successfully loaded parks data")
                        _state.update {
                            it.copy(
                                NycParks = result.value
                            )
                        }
                    }
                    is Either.Error -> {
                        Log.e(TAG, "Error: loading parks data")
                        _state.update {
                            it.copy(error = result.error)
                        }
                        sendEvent(Event.Toast(message = result.error.toString()))
                    }
                }
                _state.update {
                    it.copy(isLoading = false)
                }

            }
        }
    }

