package com.example.project2.presentation.ui.boroughs

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.project2.commons.Either
import com.example.project2.commons.Event
import com.example.project2.commons.TAG
import com.example.project2.commons.sendEvent
import com.example.project2.domain.repositories.BoroughsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

//https://youtu.be/_56f2tjs62c?si=jjNNS9auJkLC9fiw
@HiltViewModel

class BoroughsViewModel @Inject constructor(
    private val repository: BoroughsRepository

): ViewModel() {

    private  val _state = MutableStateFlow(BoroughsUIState())
    val state = _state.asStateFlow()
    init {
        Log.d(TAG, "ViewModel init: getting boroughs")
        getBoroughs()
    }
    private fun getBoroughs() {
        viewModelScope.launch {
            _state.update {
                it.copy(isLoading = true)
            }
            when (val result = repository.getBoroughs()){
                is Either.Data -> {
                    Log.d(TAG, "successfully loaded boroughs data")
                    _state.update {
                        it.copy(
                            boroughs = result.value
                        )
                    }
                }
                is Either.Error -> {
                    Log.e(TAG, "Error: loading boroughs data")
                    _state.update {
                        it.copy(error = result.error)
                    }
                    sendEvent(Event.Toast(result.error.message))
                }

                is Either.Data -> TODO()
                is Either.Error -> TODO()
            }
            _state.update {
                it.copy(isLoading = false)
            }

        }
    }
}