package com.example.project2.presentation.ui.parks

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.project2.R
import com.example.project2.data.models.NycParkResponse
import com.example.project2.presentation.ui.util.LoadingDialog
///https://youtu.be/BtHHNj3aiTQ?si=e93Jvg4X7k5nlxv-

@SuppressLint("SuspiciousIndentation")
@Composable
fun NycParksScreen(
    searchText: String,
    modifier: Modifier = Modifier,
    viewModel: NycParksViewModel,
    onParkClicked: (String) -> Unit
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    LoadingDialog(isLoading = state.isLoading)

    when {
        state.error != null -> {

            Text(text = "Error: ${state.error?.message}", modifier = modifier.padding(16.dp))
        }
        state.NycParks.isEmpty() -> {

            Text(text = "No parks available", modifier = modifier.padding(16.dp))
        }
        else -> {
            ParkList(
                parks = state.NycParks, painter1 = painterResource(id = R.drawable.nyc_parks_logo),
                painter2 = painterResource(id = R.drawable.waves_24px),
                onParkClicked = onParkClicked,
            )


        }
    }
}
@Composable
fun ParkList(

    parks: List<NycParkResponse>,
    painter1: Painter,
    painter2: Painter,
    onParkClicked: (String) -> Unit
) {
    LazyColumn {
        items(parks) { park ->
            NycParkCard(
                park = park,
                painter1 = painter1,
                painter2 = painter2,
                contentDescripton1 = "",
                contentDescripton2 = ""



            )  { onParkClicked(park.url ?: "") }
            //added



        }
    }
}


