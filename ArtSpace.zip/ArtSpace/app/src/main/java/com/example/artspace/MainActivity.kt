package com.example.artspace

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.artspace.ui.theme.ArtSpaceTheme
import java.nio.file.WatchEvent
import java.time.Year
import java.time.format.TextStyle

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ArtSpaceTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ArtSpaceButton(name = "", year = "")
                    ArtSpaceText(name = "", year = "")
                    ArtSpaceImage(name = "")

                }
            }
        }
    }
}

@Composable
fun ArtSpaceText(name: String, year: String, modifier: Modifier = Modifier){
    Column(  horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier
        .fillMaxSize()
        .padding(top = 550.dp, start = 50.dp, end = 50.dp, bottom = 120.dp)
        .background(color = Color.LightGray) ) {


        Text(text = "this chicken is call chicken male" , fontWeight = FontWeight(weight = 50), fontStyle = FontStyle.Italic)
        Text(text = "we should all eat chicken", fontWeight = FontWeight.Bold)
    }


}


@Composable
fun ArtSpaceButton(name: String, year: String, modifier: Modifier = Modifier
    .fillMaxSize() ){
    Row (horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier
        .fillMaxWidth()
        .padding(top = 680.dp, start = 8.dp, end = 8.dp, bottom = 0.dp), verticalAlignment = Alignment.Bottom){


        Button(onClick = { /*TODO*/ }) {
            Text(text = " Previous", fontSize = 15.sp)

        }
        Button(onClick = { /*TODO*/ }) {
            Text(text = " Next", fontSize = 15.sp)



        }
    }




}


@Composable
fun ArtSpaceImage(name: String, modifier: Modifier = Modifier) {
     val image = painterResource(R.drawable.james_wainscoat_yew23jxvsni_unsplash)

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 50.dp, start = 20.dp, end = 20.dp, bottom = 450.dp)
            ) {
                Image(painter = image, contentDescription = null)
            }
        }



@Preview(showBackground = true, showSystemUi = true)
@Composable
fun GreetingPreview() {
    ArtSpaceTheme {
        ArtSpaceButton(name = "", year = "")
        ArtSpaceText(name = "", year = "")
        ArtSpaceImage(name = "")

    }
}