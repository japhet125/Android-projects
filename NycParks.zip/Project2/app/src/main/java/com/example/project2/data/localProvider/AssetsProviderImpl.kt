package com.example.project2.data.localProvider

//import android.content.res.loader.AssetsProvider
import android.annotation.SuppressLint
import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

//@RequiresApi(Build.VERSION_CODES.R)
class AssetsProviderImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    ): AssetsProvider {
    override suspend fun getJsonData(fileName: String)  =
        context.assets.open(fileName).bufferedReader().use{
        it.readText()
    }
    @SuppressLint("DiscourageApi")

    override suspend fun getDrawableResourceId(name: String) =
        context.resources.getIdentifier(name, "drawable", context.packageName)



}