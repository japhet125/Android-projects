package com.example.project2.presentation.ui.navigation

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.project2.R
import com.example.project2.commons.Event
import com.example.project2.commons.sendEvent
import com.example.project2.presentation.ui.boroughs.BoroughsScreen
import com.example.project2.presentation.ui.parks.NycParksScreen
import com.example.project2.presentation.ui.parks.NycParksViewModel
import com.example.project2.util.scaffold.AppScaffold
import com.example.project2.util.scaffold.TitleText


//https://youtu.be/BtHHNj3aiTQ?si=e93Jvg4X7k5nlxv-
@SuppressLint("SuspiciousIndentation")
@Composable
fun AppNavigationGraph() {
    val navController: NavHostController = rememberNavController()
    val isBackEnabled = remember {
        mutableStateOf(false)
    }
    val title = remember {
        mutableStateOf(R.string.screen_title_home)
    }
    val titleArgs = remember {
        mutableStateOf("")
    }
    val showSearchIcon = remember {
        mutableStateOf(false)
    }
    val searchClicked = remember {
        mutableStateOf(false)
    }
    val searchText = remember {
        mutableStateOf("")
    }

    navController.addOnDestinationChangedListener { _, destination, _ ->

        Log.d("nav", "nav destination changed to ${destination.route}")

         isBackEnabled.value = !destination.route.equals(Route.HOME_SCREEN)
           if (destination.route!!.startsWith(Route.PARK_SCREEN, 0) ){
            title.value = R.string.screen_title_parks
            showSearchIcon.value = true
          } else {
         title.value = R.string.screen_title_home
          showSearchIcon.value= false
         searchClicked.value = false

         }
    }


    AppScaffold(
        title = {
            if (searchClicked.value) {
                //TODO: Project 2 SearchTextField Extra credit
                SearchTextField(placeholder = stringResource(id = R.string.search_parks_placeholder)) { value ->
                    searchText.value = value
                }
            } else {
                TitleText(title = stringResource(id = title.value, titleArgs.value))
            }
        },
        showBackIcon = isBackEnabled.value,
        onBackClick = {
            if (!searchClicked.value) navController.popBackStack()
            searchClicked.value = !searchClicked.value
        },
        showSearchIcon = showSearchIcon.value && !searchClicked.value,
        onActionClick = {
            searchClicked.value = true
        },
    ) { paddingValues ->
        Box(modifier = Modifier.padding(paddingValues)) {
            NavHost(navController = navController, startDestination = Route.HOME_SCREEN) {
                composable(Route.HOME_SCREEN) {
                    BoroughsScreen(onBoroughClicked = { borough, title ->
                        titleArgs.value = title
                        navController.navigate(Route.PARK_SCREEN + "?borough=$borough")
                    })
                }
                composable(
                    Route.PARK_SCREEN + "?borough={borough}",
                    arguments = listOf(
                        navArgument("borough") {
                            type = NavType.StringType
                        },
                    ),
                ) { backStackEntry ->
                    //TODO: Project 2 add ParksScreen Here!
                    val viewModel: NycParksViewModel = hiltViewModel()
                    val boroughCode = backStackEntry.arguments?.getString("borough")!!
 //added
//

                    val launcher = rememberLauncherForActivityResult(
                        ActivityResultContracts.StartActivityForResult()) { result ->
                        if (result.resultCode == Activity.RESULT_OK) {

                        }
                    }

                    viewModel.getNycParks(boroughCode)
                    NycParksScreen(
                        searchText = searchText.value,
                        viewModel = viewModel,
                        onParkClicked = { url ->
                            if (url.isNotEmpty()) {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))

                                launcher.launch(intent)
                            } else {
                                viewModel.sendEvent(Event.Toast("No link available for this park"))
                                Log.e("AppNavigationGraph", "Empty website url")
                            }


                        }
//

                    )

                }

            }

        }
    }
}
@Composable
fun SearchTextField(
    placeholder: String,
    onSearchTextChanged: (String) -> Unit
) {
    var searchText by remember { mutableStateOf("") }

    TextField(
        value = searchText,
        onValueChange = {
            searchText = it
            onSearchTextChanged(it)
        },
        placeholder = { Text(placeholder) },
        modifier = Modifier.fillMaxWidth(),
        trailingIcon = {
            if (searchText.isNotEmpty()) {
                IconButton(
                    onClick = { searchText = "" },
                    content = { Icon(Icons.Filled.Clear, contentDescription = "Clear") }
                )
            }

        }
    )
}

