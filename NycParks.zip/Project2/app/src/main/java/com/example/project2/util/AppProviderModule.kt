package com.example.project2.util




import android.util.Log
import com.example.project2.commons.TAG
import com.example.project2.data.local.repositories.BoroughsRepositoryImpl
import com.example.project2.data.localProvider.AssetsProvider
import com.example.project2.data.localProvider.AssetsProviderImpl
import com.example.project2.data.remote.repositories.NycOpenDataApiService
import com.example.project2.data.remote.repositories.NycParksRepositoryImpl
import com.example.project2.domain.repositories.BoroughsRepository
import com.example.project2.domain.repositories.NycParksRepository
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import retrofit2.Retrofit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class AppProviderModule {

    @Binds
    @Singleton
    abstract fun localAssetsProvider(impl: AssetsProviderImpl): AssetsProvider

    @Binds
    @Singleton
    abstract fun boroughsRepositoryProvider(impl: BoroughsRepositoryImpl): BoroughsRepository



   @Binds
    @Singleton
    abstract fun nycParksRepositoryProvider(impl: NycParksRepositoryImpl
    ): NycParksRepository

    //Api Service
    companion object {
        @Singleton
        @Provides
        fun nycOpenDataApiServiceProvider(): NycOpenDataApiService {
           val json = Json {
                ignoreUnknownKeys = true
            }
            Log.d(TAG, "building NYC open Data Api service provider")
            return Retrofit.Builder().addConverterFactory(json
                .asConverterFactory("application/json".toMediaType()))
                .baseUrl(AppConstants.NYC_OPEN_DATA_API_BASE_URL).build()
                .create(NycOpenDataApiService::class.java)
        }
   }
}