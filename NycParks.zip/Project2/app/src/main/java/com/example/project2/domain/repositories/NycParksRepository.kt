package com.example.project2.domain.repositories

import com.example.project2.commons.AppError
import com.example.project2.commons.Either
import com.example.project2.data.models.NycParkResponse


interface NycParksRepository {

    //TODO: Project 2
    suspend fun getParksByBorough(boroughCode: String): Either<AppError, List<NycParkResponse>>
}



