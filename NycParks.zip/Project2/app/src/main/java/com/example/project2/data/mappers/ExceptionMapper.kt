package com.example.project2.data.mappers

import android.os.Build
import android.util.Log
import androidx.annotation.RequiresExtension
import com.example.project2.commons.AppError
import com.example.project2.commons.TAG
import retrofit2.HttpException
import java.io.IOException

@RequiresExtension(extension = Build.VERSION_CODES.S, version = 7)
fun Throwable.toError(): AppError {
    Log.d(TAG, "mapping Exception: $this")
    val error = when (this) {
        is HttpException -> "Unknown response"
        is IOException -> "Network error"
        else -> {
            //I added this line of code to get more details about a bug that i was getting
           val errorMessage = this.message ?:  "Unknown error"
            "Error: $errorMessage"
        }
    }
    return AppError(error, throwable = this)
}