package com.example.project2.domain.model

import android.media.Image
import androidx.annotation.DrawableRes

data class Borough(val boroCode: Char,
    val  name: String,
    val longName: String,
    @DrawableRes val image: Int)
