package com.example.project2.data.mappers

import com.example.project2.data.localProvider.AssetsProvider
import com.example.project2.domain.model.NycPark
import org.json.JSONObject

//TODO: Project 2
suspend fun parksMapper(
    jsonObj: JSONObject,
    localAssetsProvider: AssetsProvider
): List<NycPark> {
    val jsonArray = jsonObj.getJSONArray("parks")
    val parks = mutableListOf<NycPark>()

    for (i in 0 until jsonArray.length()) {
        val obj = jsonArray.getJSONObject(i)
        val park = NycPark(
            name311 = obj.getString("name"),
          //  id = obj.getString("id"),
            borough = obj.getString("borough"),
            location = obj.getString("location"),
         //   retired = obj.getBoolean("retired"),
            url = obj.getString("url"),
            waterfront = obj.getBoolean("waterfront")
        )
        parks.add(park)
    }
    return parks
}

