package com.example.project2.domain.model

import kotlinx.serialization.SerialName

//TODO: Project 2
// this model represents the data from a database

data class NycPark(
    @SerialName("signname")

  //  val id: String,
    val name311: String,
    val borough: String,
    val location: String,
    //val retired: Boolean,
    val url: String,
    val waterfront: Boolean
)
