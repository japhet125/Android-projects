package com.example.project2.data.localProvider

interface AssetsProvider {

    suspend fun getJsonData(fileName: String): String
    suspend fun getDrawableResourceId(name: String): Int

}