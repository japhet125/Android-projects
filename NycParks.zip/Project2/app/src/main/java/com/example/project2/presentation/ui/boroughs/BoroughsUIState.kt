package com.example.project2.presentation.ui.boroughs

import com.example.project2.commons.AppError
import com.example.project2.domain.model.Borough

//https://youtu.be/_56f2tjs62c?si=jjNNS9auJkLC9fiw
data class BoroughsUIState(
    val isLoading: Boolean = false,
    val boroughs: List<Borough> = emptyList(),
    val error:  AppError? = null
)
