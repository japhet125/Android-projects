package com.example.project2.presentation.ui.parks

import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredHeight
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.project2.R
import com.example.project2.data.models.NycParkResponse

// TODO: project 2

@Composable
fun NycParkCard(
    park: NycParkResponse,
    painter1: Painter,
    painter2: Painter,
    contentDescripton1: String,
    contentDescripton2: String,
    onClick: () -> Unit = {},

    ) {

    val height: Dp = 148.dp
    Card(
        modifier = Modifier
            .padding(6.dp)
            .shadow(
                elevation = 6.dp,
                spotColor = MaterialTheme.colorScheme.surfaceTint,

            )
            .requiredHeight(height).clickable { onClick() }
    ) {

        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp)
                .border(2.dp, MaterialTheme.colorScheme.secondary),
            //horizontalAlignment = Alignment.Start
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Image(
                painter = painter1,
                contentDescription = contentDescripton1,
                contentScale = ContentScale.Crop,
                modifier = Modifier.padding(
                    start = 16.dp,
                    end = 5.dp,
                    top = 16.dp,
                    bottom = 16.dp
                )
            )
            if (park.waterfront) {
                Image(
                    painter = painter2,
                    contentDescription = contentDescripton2,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(20.dp).padding()

                )
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(
                        start = 5.dp,
                        end = 16.dp,
                        top = 16.dp,
                        bottom = 16.dp
                    )
            ) {
                Text(
                    text = park.name,
                    textAlign = TextAlign.Start,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Text(
                    text = park.location,
                    textAlign = TextAlign.Start,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontSize = 12.sp
                )
            }

        }

    }
}
@Preview(showBackground = true, showSystemUi = true)
@Composable
fun NycParkCArdPreview(){
    NycParkCard(
        park = NycParkResponse(
            borough = "M",
            name = "11 BC Serenity Garden",
            location = "E 11 St. bet. Ave. B and Ave. C, some other address info.",
            retired = false,
            waterfront = false,
            url = ""

        ),
        painter1 = painterResource(id = R.drawable.nyc_parks_logo),
        painter2 = painterResource(id = R.drawable.waves_24px),
        contentDescripton1 = "",
        contentDescripton2 = ""

    )
}