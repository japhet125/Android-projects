package com.example.project2.data.remote.repositories

import android.os.Build
import android.util.Log
import androidx.annotation.RequiresExtension
import com.example.project2.commons.AppError
import com.example.project2.commons.Either
import com.example.project2.commons.TAG
import com.example.project2.data.mappers.toError
import com.example.project2.data.models.NycParkResponse
import com.example.project2.domain.repositories.NycParksRepository
import javax.inject.Inject

class NycParksRepositoryImpl @Inject constructor(
    private val nycOpenDataApiService: NycOpenDataApiService
) : NycParksRepository {
    //TODO: Project 2

//    private suspend fun loadJsonAndMapData(boroughCode: String): List<NycPark> {
//        val json = loadJson(boroughCode)
//        return parksMapper(json, localAssetsProvider)
//    }
//
//    private suspend fun loadJson(boroughCode: String): JSONObject {
//        val jsonString = nycOpenDataApiService.getNycParks(boroughCode)
//        return JSONObject(jsonString)
//    }


    @RequiresExtension(extension = Build.VERSION_CODES.S, version = 7)
    override suspend fun getParksByBorough(boroughCode: String): Either<AppError, List<NycParkResponse>> {
        Log.d(TAG, "assets provider loading parks from JSON file")
        return try {
            val parks = nycOpenDataApiService.getNycParks(boroughCode)
            Either.Data(parks)
        } catch (e: Exception) {
            Either.Error(e.toError())
        }
    }


}