package com.example.project2.data.models

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

//TODO : Project 2
@Serializable
data class NycParkResponse(
//    val id: Int,
    @SerialName("signname")
    val name: String,
    val borough: String,
    val location: String,
    val retired: Boolean,
    val waterfront: Boolean,
    val url: String? = null
)
