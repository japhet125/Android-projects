package com.example.project2.data.remote.repositories

import com.example.project2.data.models.NycParkResponse
import retrofit2.http.GET
import retrofit2.http.Query

interface NycOpenDataApiService {
// Query: borough
    //'M' -> is Manhattan
    //'X' -> is Bronx
    //'Q' -> is Queens
    //'B' -> is Brooklyn
    //'R' -> is Staten Island
    @GET("enfh-gkve.json")
    suspend fun getNycParks(
        @Query("borough") borough: String,
        @Query("retired") retired: Boolean = false,
    ) : List<NycParkResponse>
}