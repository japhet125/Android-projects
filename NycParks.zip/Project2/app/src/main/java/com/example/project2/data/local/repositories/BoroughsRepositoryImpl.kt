package com.example.project2.data.local.repositories

import android.os.Build
import android.util.Log
import androidx.annotation.RequiresExtension
import com.example.project2.commons.AppError
import com.example.project2.commons.Either
import com.example.project2.commons.TAG
import com.example.project2.data.localProvider.AssetsProvider
import com.example.project2.data.mappers.boroughsMapper
import com.example.project2.data.mappers.toError
import com.example.project2.domain.model.Borough
import com.example.project2.domain.repositories.BoroughsRepository
import com.example.project2.util.AppConstants
import org.json.JSONObject
import javax.inject.Inject

class BoroughsRepositoryImpl @Inject constructor(
    private val localAssetsProvider: AssetsProvider,
) : BoroughsRepository{

    private suspend fun loadJsonAndMapData(): List<Borough> {
        val json = loadJson()
        return boroughsMapper(json, localAssetsProvider)
    }
    private suspend fun loadJson(): JSONObject {
        val jsonString = localAssetsProvider.getJsonData(AppConstants.BOROUGHS_JSON)
        return JSONObject(jsonString)
    }

    @RequiresExtension(extension = Build.VERSION_CODES.S, version = 7)
    override suspend fun getBoroughs(): Either<AppError, List<Borough>> {
        Log.d(TAG, "assets provider loading boroughs from JSON file")
        return try {
            Either.Data(loadJsonAndMapData()) } catch (e: Exception) {
                Either.Error(e.toError())
        }
    }
}